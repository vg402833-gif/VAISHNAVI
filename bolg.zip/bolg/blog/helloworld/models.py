from django.db import models
from django.contrib.auth import get_user_model
User = get_user_model()
# Create your User = get_user_model()models here.
class Post(models.Model):
    title=models.CharField(max_length=200)
    content=models.TextField()
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(auto_now=True)
    created_by=models.ForeignKey(User,on_delete=models.CASCADE)
    def __str__(self):
        return self.title
    