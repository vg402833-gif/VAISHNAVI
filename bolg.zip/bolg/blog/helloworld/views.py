from django.shortcuts import render
from rest_framework.permissions import IsAuthenticated
from helloworld.models import Post
from rest_framework.response import Response
from rest_framework.decorators import APIView
from helloworld.serializers import PostSerializer
from rest_framework.viewsets import ModelViewSet
class HelloWorldView(APIView):
    def get(self, request):
        return Response({'message':'HelloWorld'})
class PostView(ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Post.objects.all()
    serializers_class = PostSerializer
    def get_query_set(self):
        return Post.objects.filter(createdby_=self.request.user)
    