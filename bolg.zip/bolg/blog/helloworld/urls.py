from django.contrib import admin
from django.urls import path,include
from helloworld.views import HelloWorldView
from helloworld.views import PostView
from rest_framework import routers
urlpatterns=[
    path('admin/', admin.site.urls),
    path('hello/',HelloWorldView.as_view()),
    path('api_auth/',include('rest_framework.urls')),
]
router = routers.SimpleRouter()
router.register('post',PostView,basename="post")
urlpatterns += router.urls